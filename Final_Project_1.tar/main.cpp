#include "mbed.h"
#include "rtos.h"
#include "uLCD_4DGL.h"
#include "SongPlayer.h"
#include "ultrasonic.h"

//uLCD
uLCD_4DGL LCD(p28,p27,p30); // serial tx, serial rx, reset pin;

float note[1]= {1700.0};
float duration[1]= {0.5};
//Declare global variables
volatile int current_distance = 500;
volatile int current_speed = 100;

// mutex to make the lcd lib thread safe
Mutex lcd_mutex;
SongPlayer mySpeaker(p24);
//Distance fucntion for sonar sensor
void dist(int distance)
{
    //printf("Distance %d mm\r\n", distance);
    current_distance = distance;
}

ultrasonic mu(p6, p7, .1, 1, &dist);    //Set the trigger pin to D8 and the echo pin to D9
                                        //have updates every .1 seconds and a timeout after 1
                                        //second, and call dist when the distance changes

//Sonar Sensor Thread
void Sensor_Thread(void const *args)
{
    mu.startUpdates();//start measuring the distance
    while(1)
    {
        mu.checkDistance();     //call checkDistance() as much as possible, as this is where
                                //the class checks if dist needs to be called.
        Thread::wait(50);
    }
}

//uLCD thread
void uLCD_Thread(void const *args)
{
    while(1) {       // thread loop
        lcd_mutex.lock();
        LCD.color(GREEN);
        LCD.locate(0,0);
        LCD.text_height(2);
        LCD.text_width(2);
        LCD.printf("Distance:");
        LCD.locate(0,2);
        LCD.printf("%2.0d mm         ",current_distance);
        LCD.locate(0,4);
        LCD.color(RED);
        LCD.printf("Speed:");
        LCD.locate(0,6);
        LCD.printf("%2.0d mm         ",current_speed);
        lcd_mutex.unlock();
        Thread::wait(50);
    }
}

// Audio
void Audio_Thread(void const *args)
{
    while(1) {         // thread loop
        if ((current_distance <= 100) && !audio_on ){
                mySpeaker.PlaySong(note,duration);
                wait(0.8);
        } 
        Thread::wait(200);
    }
}

int main()
{
    Thread sonar(Sensor_Thread); //start Sensor_Thread
    Thread uLCD(uLCD_Thread);
    Thread audio(Audio_Thread);
        while(1){
            Thread::wait (1000);
        }
}
